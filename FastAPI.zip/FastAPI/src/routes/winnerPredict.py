from fastapi import APIRouter
from src.models import modelInference
from pydantic import BaseModel
#instance of APIRouter
router = APIRouter()
#define model (WinnerPredict) to validate the request body
class WinnerPredict(BaseModel):
    team1: str
    team2: str
    venue: str
#define route for endpoint "/winnerpredict" with HTTP method "POST"
@router.post("/winnerpredict")
async def PredictWinner(params: WinnerPredict):
    winner = modelInference.fine_winner(params.team1, params.team2, params.venue)
    return {
                "winning_team": winner
            }