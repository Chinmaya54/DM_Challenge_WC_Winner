Steps performed 
1) pip install "fastapi[all]"
2) Make sure pkl file is in data/ folder
3) start the server "python -m uvicorn main:app --reload"
4) access endpoint request through Thunder Client
-- Install the Thunder Client extension.
-- Open a new Thunder Client tab by clicking on the Thunder Client icon in the sidebar.
-- Set the HTTP method to POST.
-- Set the URL to 
    url: http://127.0.0.1:8000/winnerpredict
-- In the "Body" section, select JSON and enter the following JSON data:
    body[JSON]: {
	"match": "semi2",
	"team1": "South Africa",
  "team2": "Australia",
  "venue": "Eden Gardens"
}
-- Click the "Send Request" button to send the request to your FastAPI application.
5) Received a response with the predicted winner in the Thunder Client interface.
Note: Thunder Client extension which is a lightweight Rest API Client Extension for VS Code. It is used for testing API endpoints 